package com.app.superpos.utils;

public class WCharMapperCT42BNazanin extends WCharMapperCT41 {


}
