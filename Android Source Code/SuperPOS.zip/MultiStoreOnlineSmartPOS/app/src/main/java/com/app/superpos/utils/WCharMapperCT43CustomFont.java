package com.app.superpos.utils;

public class WCharMapperCT43CustomFont extends WCharMapperCT41 {

}
