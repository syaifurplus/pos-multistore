package com.app.superpos.utils;

import android.content.Context;

/**
 * Created by Saeed on 01/06/2018.
 */
public class RongtaPrnMng extends BixolonPrnMng {

    public RongtaPrnMng(Context c, String deviceAddr, IPrintToPrinter prnToWoosim) {
        super(c, deviceAddr, prnToWoosim);
    }
}
